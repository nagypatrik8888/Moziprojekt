// Login oldal funkciók
document.addEventListener('DOMContentLoaded', function() {
    // Ha már be van jelentkezve, átirányítás
    const currentUser = getCurrentUser();
    if (currentUser) {
        window.location.href = 'profile.html';
    }
    
    // Form kezelése
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
});

function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    // Demo bejelentkezés
    if (email === 'demo@cinemax.hu') {
        const user = {
            id: 1,
            name: 'Demo User',
            email: email,
            phone: '+36 20 123 4567',
            bookings: 0,
            points: 0
        };
        
        setCurrentUser(user);
        showToast('Sikeres bejelentkezés! Üdvözlünk!');
        
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 1000);
    } else {
        showToast('Hibás email vagy jelszó! Próbáld: demo@cinemax.hu', true);
    }
}

function showRegister() {
    showToast('Regisztráció jelenleg nem elérhető. Használd: demo@cinemax.hu');
}